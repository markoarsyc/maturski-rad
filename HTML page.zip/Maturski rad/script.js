function pocetna() {
	window.location.href = "index.html";
}
function polozaj() {
	window.location.href = "polozaj.html";
}
function znamenitosti() {
	window.location.href = "znamenitosti.html";
}
function istorija() {
	window.location.href = "istorija.html";
}
function desavanja() {
	window.location.href = "desavanja.html";
}
function nocni_zivot() {
	window.location.href = "nocni_zivot.html";
}
function o_stranici() {
	window.location.href = "o_stranici.html";
}